package org.example.sound;

import java.io.*;
import javax.sound.sampled.*;

public class AudioFileType {

    public static void main(String[] args) {
        // Укажите путь к вашей папке
        String folderPath = "outFile\\"; // Замените на свой путь

        File folder = new File(folderPath);

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();

            if (files != null) {
                for (File file : files) {
                    String fileName = file.getName();
                    String fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();

                    if ("wav".equals(fileExtension)) {
                        System.out.println("Тип файла WAV");
                    } else if ("mp3".equals(fileExtension)) {
                        System.out.println("Тип файла MP3");
                    } else {
                        System.out.println("Неизвестный тип файла");
                    }
                }
            } else {
                System.out.println("Папка пуста");
            }
        } else {
            System.out.println("Указанный путь не является директорией или не существует");
        }
    }

}
