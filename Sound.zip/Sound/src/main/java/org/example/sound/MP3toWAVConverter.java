package org.example.sound;

import javazoom.jl.converter.Converter;
import javazoom.jl.decoder.JavaLayerException;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class MP3toWAVConverter {

    public static void convertMP3toWAV(String mp3FilePath, String wavFilePath) {
        try {
            // Используем JLayer для декомпрессии MP3 в WAV
            Converter converter = new Converter();
            converter.convert(mp3FilePath, wavFilePath);

            System.out.println("Преобразование прошло успешно!");
        } catch (JavaLayerException e) {
            System.out.println("Ошибка номер 1!!");
        }
    }

    private static void convertWavToMp3(String wavFilePath, String mp3FilePath) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(wavFilePath));

            AudioFormat sourceFormat = audioInputStream.getFormat();
            AudioFormat convertFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                    sourceFormat.getSampleRate(), 16, sourceFormat.getChannels(),
                    sourceFormat.getChannels() * 2, sourceFormat.getSampleRate(), false);

            AudioInputStream convertedStream = AudioSystem.getAudioInputStream(convertFormat, audioInputStream);

            // Настройка кодека для MP3
            AudioFormat targetFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                    sourceFormat.getSampleRate(), 16, 1, 2, sourceFormat.getSampleRate(), false);

            AudioInputStream mp3Stream = AudioSystem.getAudioInputStream(targetFormat, convertedStream);

            AudioSystem.write(mp3Stream, AudioFileFormat.Type.WAVE, new File(mp3FilePath));

            audioInputStream.close();
            convertedStream.close();
            mp3Stream.close();

            System.out.println("Конвертация завершена успешно");
        } catch (UnsupportedAudioFileException | IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String mp3FilePath = "1.mp3";
        String wavFilePath = "1.wav";
        String convertedMP3FilePath = "1_converted.mp3";

        // Convert MP3 to WAV
        convertMP3toWAV(mp3FilePath, wavFilePath);

        // Convert WAV to MP3
        convertWavToMp3(wavFilePath, convertedMP3FilePath);
    }
}
