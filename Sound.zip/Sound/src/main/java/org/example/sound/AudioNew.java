package org.example.sound;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class AudioNew {

    public static void main(String args[]) throws IOException {
        File WAV_FILE = new File("outFile\\1.wav");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        AudioInputStream in = null;
        try {
            in = AudioSystem.getAudioInputStream(WAV_FILE);
        } catch (UnsupportedAudioFileException | IOException e) {
            e.printStackTrace();
        }

        int read;
        byte[] buff = new byte[1024];
        while ((read = in.read(buff)) > 0) {
            out.write(buff, 0, read);
        }
        out.flush();
        byte[] audioBytes = out.toByteArray();

        // Преобразуем байты в целые числа (8-битные звуковые образцы)
        int[] audioIntegers = new int[audioBytes.length];
        for (int i = 0; i < audioBytes.length; i++) {
            audioIntegers[i] = audioBytes[i] & 0xFF;
        }

        // Выводим пример значения звукового образца для дебага
        System.out.println(audioIntegers[700]);

        // Преобразуем целые числа обратно в байты
        byte[] audioBytes2 = new byte[audioIntegers.length];
        for (int i = 0; i < audioIntegers.length; i++) {
            audioBytes2[i] = (byte) audioIntegers[i];
        }

        // Выводим значения массива целых чисел для дебага
        for (int t : audioIntegers) {
            System.out.print(t + " ");
        }
        System.out.println("\n");

        // Выводим информацию о минимальном и максимальном значениях
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        for (int i : audioIntegers) {
            if (i > max) {
                max = i;
            }

            if (i < min) {
                min = i;
            }
        }

        System.out.println("Минимальный элемент: " + min);
        System.out.println("Максимальный элемент: " + max);

        // Проверка на идентичность двух массивов
        boolean arraysEqual = Arrays.equals(audioBytes, audioBytes2);

        if (arraysEqual) {
            System.out.println("Массивы идентичны.");
        } else {
            System.out.println("Массивы различны.");
        }

        // Создаем объект AudioFormat на основе параметров аудио
        AudioFormat audioFormat = new AudioFormat(44100, 16, 1, true, false);

        // Создаем AudioInputStream из байтового массива
        AudioInputStream audioInputStream = new AudioInputStream(
                new java.io.ByteArrayInputStream(audioBytes2),
                audioFormat,
                audioBytes2.length / audioFormat.getFrameSize()
        );

        // Создаем файл для записи аудио (2.wav)
        File outputFile = new File("2.wav");

        // Записываем AudioInputStream в файл
        AudioSystem.write(audioInputStream, AudioFileFormat.Type.WAVE, outputFile);

        // Выводим путь к созданному файлу
        System.out.println("Файл создан: " + outputFile.getAbsolutePath());
    }
}


