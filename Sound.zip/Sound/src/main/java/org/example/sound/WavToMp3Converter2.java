package org.example.sound;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class WavToMp3Converter2 {

    public static void moveAndRenameFile(String sourcePath, String newFolderPathAndName) {
        try {
            // Create a File object for the source file
            File sourceFile = new File(sourcePath);

            // Split the new folder path and file name
            String[] parts = newFolderPathAndName.split("/");
            String newFolder = parts[0];
            String newFileName = parts[1];

            // Create a Path object for the new path and file name
            Path newPath = Paths.get(newFolder, newFileName);

            // Move and rename the file
            Files.move(sourceFile.toPath(), newPath, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("File successfully moved to " + newPath.toString());
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("An error occurred while moving the file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        String inputFilePath = "temporary_store_audio/1.wav";
        String outputFilePath = "temporary_store_audio/1.mp3";

        if (convertWavToMp3(inputFilePath, outputFilePath)) {
            System.out.println("Конвертация завершена успешно.");
            deleteAllFiles("temporary_store_audio/");
        } else {
            System.out.println("Произошла ошибка при конвертации.");
        }

        moveAndRenameFile("temporary_store_audio/1.wav", "intFile/3.wav");
    }

    public static boolean convertWavToMp3(String inputFilePath, String outputFilePath) {
        try {
            File inputFile = new File(inputFilePath);
            File outputFile = new File(outputFilePath);

            // Создаем аудио-входной поток из файла WAV
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(inputFile);
            AudioFormat sourceFormat = audioInputStream.getFormat();

            // Создаем аудио-выходной поток для формата MP3
            AudioFormat targetFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    sourceFormat.getSampleRate(),
                    16,
                    sourceFormat.getChannels(),
                    sourceFormat.getChannels() * 2,
                    sourceFormat.getSampleRate(),
                    false);

            AudioInputStream convertedAudioInputStream = AudioSystem.getAudioInputStream(targetFormat, audioInputStream);

            // Записываем преобразованный поток в файл MP3
            AudioSystem.write(convertedAudioInputStream, AudioFileFormat.Type.WAVE, outputFile);

            // Освобождаем ресурсы
            audioInputStream.close();
            convertedAudioInputStream.close();

            System.out.println("Конвертация завершена успешно.");
            return true;
        } catch (Exception e) {
            System.err.println("Ошибка при конвертации: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static void deleteAllFiles(String folderPath) {
        try {
            File folder = new File(folderPath);

            // Получаем список всех файлов в папке
            File[] files = folder.listFiles();

            if (files != null) {
                // Удаляем каждый файл
                for (File file : files) {
                    if (file.isFile()) {
                        file.delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}